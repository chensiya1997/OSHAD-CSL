"""
Anomaly Detection in Streams with Extreme Value Theory
"""
from .spot import SPOTBase
from .spot import SPOT
from .spot import biSPOT
from .spot import dSPOT
from .spot import bidSPOT
